<?php 

// ~~~~~~~~~~~~~~~~~~~~~~~~~
// AUTHOR: Viktor Hančovský
//  login: xhanco00
// ~~~~~~~~~~~~~~~~~~~~~~~~~

namespace IPP\Student;

use IPP\Core\AbstractInterpreter;
use IPP\Core\ReturnCode;
use IPP\Student\Instruction;
use IPP\Student\Exception\InterpretRuntimeException;
use IPP\Student\Frame;
use IPP\Student\Symbol;

class Interpreter extends AbstractInterpreter
{
    /** @var Instruction[] */
    public array $instructions = [];
    /** @var Argument[] */
    public array $arguments = [];
    public $labels = [];
    public Frame $gf;
    public Frame $tf;
    /** @var Frame[] */
    public array $lf = [];
    private $return_code;
    private int $instr_ptr = 0;
    private int $inst_cnt = 0;
    private array $call_stack = [];
    private array $stack = [];

    public function execute(): int {
        $this->return_code = ReturnCode::OK;

        // Check \IPP\Core\AbstractInterpreter for predefined I/O objects:
        $dom = $this->source->getDOMDocument();
        
        // Check if the root element is <program>
        if ($dom->documentElement->nodeName !== 'program') {
            throw new InterpretRuntimeException("Root node is not <program>", ReturnCode::INVALID_SOURCE_STRUCTURE);
        } 
        else {
            if ($dom->documentElement->hasAttribute('language') &&
                strtoupper($dom->documentElement->getAttribute('language')) != 'IPPCODE24') {
                throw new InterpretRuntimeException("Invalid language value", ReturnCode::INVALID_SOURCE_STRUCTURE);
            }
        }

        $name = $description = "";
        // Check for attributes 'name' and 'description' 
        if ($dom->documentElement->hasAttribute('name')) {
            $name = $dom->documentElement->getAttribute('name');
        }
        if ($dom->documentElement->hasAttribute('description')) {
            $description = $dom->documentElement->getAttribute('description');
        }

        // Check if there are only <instruction> elements inside <program> element
        foreach ($dom->documentElement->childNodes as $child) {
            if ($child->nodeType === XML_ELEMENT_NODE && $child->nodeName !== 'instruction') {
                // If a non-instruction element is found, return an error
                throw new InterpretRuntimeException("Unknown element",ReturnCode::INVALID_SOURCE_STRUCTURE);
            }

            // Check attributes of each instruction
            if ($child->nodeType === XML_ELEMENT_NODE && $child->nodeName === 'instruction') {
                $ca = $child->attributes;
                $ca_keys = [];
                foreach ($ca as $attr) {
                    $ca_keys[] = $attr->nodeName;
                }

                if (!in_array('order', $ca_keys) || !in_array('opcode', $ca_keys)) {
                    // If order or opcode attribute is missing, return an error
                    throw new InterpretRuntimeException("instruction opcode/order missing", ReturnCode::INVALID_SOURCE_STRUCTURE);
                }

                // Check if there are only <arg1>, <arg2>, <arg3> elements inside each <instruction> element
                foreach ($child->childNodes as $subelem) {
                    if ($subelem->nodeType === XML_ELEMENT_NODE && !preg_match("/^arg[123]$/", $subelem->nodeName)) {
                        // If a non-argument element is found, return an error
                        throw new InterpretRuntimeException("Invalid argument identifier", ReturnCode::INVALID_SOURCE_STRUCTURE);
                    }
                }
            }
        }

        // Proceed with processing the instructions
        foreach ($dom->getElementsByTagName('instruction') as $element) {
            $inst_opcode = $element->getAttribute('opcode');
            $inst_order = $element->getAttribute('order');

            // Check if opcode and order are present
            if ($inst_opcode && $inst_order) {
                $args = $element;
                $this->instructions[] = new Instruction($inst_order, $inst_opcode, $args);
            } 
            else {
                // Handle the error when opcode or order is missing
                throw new InterpretRuntimeException("instruction opcode/order missing", ReturnCode::INVALID_SOURCE_STRUCTURE);
            }
        }

        // Sort instructions based on order
        usort($this->instructions, function ($a, $b) {
            $result = $a->order - $b->order;
            if ($result === 0 || $a->order < 0 || $b->order < 0) {
                throw new InterpretRuntimeException("same/negative instruction order", ReturnCode::INVALID_SOURCE_STRUCTURE);
            }
            return $result;
        });

        $i = 0;
        foreach($this->instructions as $instruction) {
            if ($instruction->opcode == "LABEL") {
                $l_name = $instruction->arguments[0]->value;
                if (array_key_exists($l_name, $this->labels)) {
                    throw new InterpretRuntimeException("Redefinition of the same label -" . $l_name, ReturnCode::SEMANTIC_ERROR);
                }
                $this->labels[$l_name] = $i;
            }
            $i++;
        }
        
        $this->gf = new Frame();

        // Iterate through sorted instructions and create Instruction objects
        $nof_instructions = count($this->instructions);
        while($this->instr_ptr < $nof_instructions) {
            $next = $this->inst_switch($this->instructions[$this->instr_ptr]);
            if ($next === "exit") { // stop executing remaining instructions
                break;
            } else if ($next !== "no_jump") { // when jump to another instruction
                $this->instr_ptr = $next;
            }
            $this->instr_ptr++;
        }
        return $this->return_code;
    }

    public function inst_switch($instruction): mixed {
        switch ($instruction->opcode) {
            case 'CREATEFRAME':                                     // <>
                $this->tf = new Frame();

                $this->inst_cnt++;
                break;
            case 'PUSHFRAME':
                if (!isset($this->tf)) {
                    throw new InterpretRuntimeException("Attempt to access undefined frame", ReturnCode::FRAME_ACCESS_ERROR);
                }
                $this->lf[] = $this->tf;
                unset($this->tf);

                $this->inst_cnt++;
                break;
            case 'POPFRAME':
                if (count($this->lf) == 0) {
                    throw new InterpretRuntimeException("No frame in LF available", ReturnCode::FRAME_ACCESS_ERROR);
                }
                $this->tf = array_pop($this->lf);
                
                $this->inst_cnt++;
                break;
            case 'RETURN':
                if (count($this->call_stack) == 0) {
                    throw new InterpretRuntimeException("Calling RETURN on empty call stack", ReturnCode::VALUE_ERROR);
                }
                return array_pop($this->call_stack);
                
                $this->inst_cnt++;
                break;
            case 'BREAK':
                // Position in code
                $this->stdout->writeString("Position in code: " . $this->instr_ptr . "\n");

                // Contents of each frame
                $this->stdout->writeString("--- GF ---" . "\n");
                print_r($this->gf->data);

                $this->stdout->writeString("--- TF ---" . "\n");
                if (isset($this->tf)) print_r($this->tf->data);
                
                $this->stdout->writeString("--- LF ---" . "\n");
                foreach ($this->lf as $lf) {
                    print_r($lf->data);
                }

                // Amount of interpreted instructions
                $this->inst_cnt++;
                $this->stdout->writeString("Instructions interpreted: " . $this->inst_cnt . "\n");
                break;

            case 'DEFVAR':                                          // <var>
                $varName = $instruction->arguments[0]->value;
                $frame = $this->get_frame_from_name($varName);
                if (!$frame) {
                    throw new InterpretRuntimeException("Frame " . $frame . " not initialized", ReturnCode::FRAME_ACCESS_ERROR);
                }
                $frame->init_variable(substr($varName, 3), null, null);
                
                $this->inst_cnt++;
                break;
            case 'POPS':
                if (count($this->stack) == 0) {
                    throw new InterpretRuntimeException("Calling POPS on empty stack", ReturnCode::VALUE_ERROR);
                }
                $var = $this->get_symbol($instruction->arguments[0]);
                $symb_from_stack = array_pop($this->stack);
                $var->type = $symb_from_stack->type;
                $var->value = $symb_from_stack->value;
                
                $this->inst_cnt++;
                break;

            case 'PUSHS':                                           // <symb>
                $symb = $this->get_symbol($instruction->arguments[0]);
                $this->stack[] = new Symbol($symb->value, $symb->type,$symb->name);

                // print("STAAAAAAAAAAAAAAAAAAAAAAACK\n");
                // print_r($this->stack);
                $this->inst_cnt++;
                break;
            case 'WRITE':        
                $symbol = $this->get_symbol($instruction->arguments[0]);
                
                switch($symbol->type) {
                    case "int":
                        $this->stdout->writeInt($symbol->value);
                        break;
                    case "bool":
                        $this->stdout->writeBool($symbol->value);
                        break;
                    case "string":
                        $this->stdout->writeString($symbol->value);
                        break;
                    case "nil":
                        $this->stdout->writeString("");
                        break;
                    case "float":
                        $this->stdout->writeFloat($symbol->value);
                        break;
                    default:
                        throw new InterpretRuntimeException("Variable not initialized", ReturnCode::VARIABLE_ACCESS_ERROR);
                }

                $this->inst_cnt++;
                break;           
            case 'EXIT':
                $symbol = $this->get_symbol($instruction->arguments[0]);
                
                if ($symbol->type != "int") {
                    throw new InterpretRuntimeException("Type not \"int\" or value out of interval <0,9>", ReturnCode::OPERAND_TYPE_ERROR);
                }
                if ($symbol->type == "int" && ($symbol->value < 0 || $symbol->value > 9)) {
                    throw new InterpretRuntimeException("Type not \"int\" or value out of interval <0,9>", ReturnCode::OPERAND_VALUE_ERROR);
                }
                
                $this->return_code = $symbol->value;
                
                $this->inst_cnt++;
                return "exit";
                break;
            case 'DPRINT':
                $symbol = $this->get_symbol($instruction->arguments[0]);
                $this->stderr->writeString($symbol->value);
                
                $this->inst_cnt++;
                break;

            case 'CALL':                                            // <label>
                $l_name = $instruction->arguments[0]->value;
                if (!array_key_exists($l_name, $this->labels)) {
                    throw new InterpretRuntimeException("Call to undefined label -" . $l_name, ReturnCode::SEMANTIC_ERROR);
                }
                $this->call_stack[] = $this->instr_ptr;
                
                $this->inst_cnt++;
                return $this->labels[$l_name];
                break;
            case 'LABEL':
                $this->inst_cnt++;
                // PASS
                break;
            case 'JUMP':
                $l_name = $instruction->arguments[0]->value;
                if (!array_key_exists($l_name, $this->labels)) {
                    throw new InterpretRuntimeException("Call to undefined label -" . $l_name, ReturnCode::SEMANTIC_ERROR);
                }
                
                $this->inst_cnt++;
                return $this->labels[$l_name];
                break;

            case 'MOVE':                                            // <var> <symb>
                $var = $this->get_symbol($instruction->arguments[0]);
                $symb = $this->get_symbol($instruction->arguments[1]);
                
                if (!$symb->type) {
                    throw new InterpretRuntimeException("Variable not initialized", ReturnCode::VARIABLE_ACCESS_ERROR);
                }
                
                $var->type = $symb->type;
                $var->value = $symb->value;
                
                $this->inst_cnt++;
                break;
            case 'INT2CHAR':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symb = $this->get_symbol($instruction->arguments[1]);
                
                if ($symb->type !== 'int') {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                $char = mb_chr($symb->value, "UTF-8");
                if (!$char) {
                    throw new InterpretRuntimeException("Failed to convert integer to character", ReturnCode::STRING_OPERATION_ERROR);
                }
                
                $var->type = "string";
                $var->value = $char;
                
                $this->inst_cnt++;
                break;
            case 'STRLEN':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symb = $this->get_symbol($instruction->arguments[1]);
                
                if ($symb->type == 'string') {
                    $var->value = strlen($symb->value);
                    $var->type = "int";
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'TYPE':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symb = $this->get_symbol($instruction->arguments[1]);
                
                $var->type = "string";
                if (!$symb->type) {
                    $var->value = "";
                } else {
                    $var->value = $symb->type;
                }
                
                $this->inst_cnt++;
                break;
            case 'NOT':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                
                if ($symbol1->type == "bool") {
                    if ($symbol1->value == true) {
                        $var->type = "bool";
                        $var->value = false;
                        
                    }
                    elseif ($symbol1->value == false) {
                        $var->type = "bool";
                        $var->value = true;
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;

            case 'READ':                                            // <var> <type>
                $var = $this->get_symbol($instruction->arguments[0]);
                $type = $instruction->arguments[1]->value;
                
                switch($type){
                    case "int":
                        $n = $this->input->readInt();
                        break;
                    case "string":
                        $n = $this->input->readString();
                        break;
                    case "bool":
                        $n = $this->input->readBool();
                        break;
                    default:
                        // taken care of in Argument
                }
                $var->type = $type;
                if ($n === null) {
                    $var->type = "nil";
                }
                $var->value = $n;
                
                $this->inst_cnt++;
                break;
                
            case 'ADD':                                             // <var> <symb> <symb>
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == 'int' && $symbol2->type == 'int') {
                    $var->value = $symbol1->value + $symbol2->value;
                    $var->type = "int";
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'SUB':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == 'int' && $symbol2->type == 'int') {
                    $var->value = $symbol1->value - $symbol2->value;
                    $var->type = "int";
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'MUL':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == 'int' && $symbol2->type == 'int') {
                    $var->value = $symbol1->value * $symbol2->value;
                    $var->type = "int";
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'IDIV':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if (($symbol1->type == 'int' && $symbol2->type == 'int') && ($symbol2->value != 0)) {
                    $var->value = $symbol1->value / $symbol2->value;
                    $var->type = "int";
                }
                elseif ($symbol2->value === 0) {
                    throw new InterpretRuntimeException("Division by 0", ReturnCode::OPERAND_VALUE_ERROR);
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'LT':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == $symbol2->type && ($symbol1->type != "nil" && $symbol2->type != "nil")) {
                    if ($symbol1->value < $symbol2->value) {
                        $var->type = "bool";
                        $var->value = true;
                    }
                    else {
                        $var->type = "bool";
                        $var->value = false;
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                } 
                
                $this->inst_cnt++;
                break;            
            case 'GT':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == $symbol2->type && ($symbol1->type != "nil" && $symbol2->type != "nil")) {
                    if ($symbol1->value > $symbol2->value) {
                        $var->type = "bool";
                        $var->value = true;
                    }
                    else {
                        $var->type = "bool";
                        $var->value = false;
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'EQ':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);

                if (!$symbol1->type || !$symbol2->type) {
                    throw new InterpretRuntimeException("Accessing not initialized variable", ReturnCode::VALUE_ERROR);
                }

                if ($symbol1->type != $symbol2->type && $symbol1->type != "nil" && $symbol2->type != "nil") {
                    throw new InterpretRuntimeException("Incompatible operand types in EQ", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $var->type = 'bool';
                if ($symbol1->value === $symbol2->value) {
                    $var->value = true;
                } 
                else {
                    $var->value = false;
                }

                $this->inst_cnt++;
                break;
            case 'AND':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == 'bool' && $symbol2->type == 'bool') {
                    if ($symbol1->value == "true" && $symbol2->value == "true") {
                        $var->type = "bool";
                        $var->value = true;
                    }
                    else {
                        $var->type = "bool";
                        $var->value = false;
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'OR':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                
                if ($symbol1->type == 'bool' && $symbol2->type == 'bool') {
                    if ($symbol1->value == false && $symbol2->value == false) {
                        $var->type = "bool";
                        $var->value = false;
                        
                    }
                    else {
                        $var->type = "bool";
                        $var->value = true;
                        
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'STRI2INT':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
            
                if ($symbol1->type === "string" && $symbol2->type === "int" && $symbol2->value >= 0) {
                    if ($symbol2->value < strlen($symbol1->value)) {
                        $var->value = mb_ord($symbol1->value[$symbol2->value], "UTF-8");
                        $var->type = "int";
                    } 
                    else {
                        throw new InterpretRuntimeException("Invalid string operation", ReturnCode::STRING_OPERATION_ERROR);
                    }
                } 
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'CONCAT':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);

                
                if ($symbol1->type == "string" && $symbol2->type == "string") {
                    $var->value = $symbol1->value . $symbol2->value;
                    $var->type = $symbol1->type;
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'GETCHAR':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);

                
                if ($symbol1->type == "string" && $symbol2->type == "int" && $symbol2->value >= 0) {
                    if ($symbol2->value <= strlen($symbol1->value)) {
                        $var->value = $symbol1->value[$symbol2->value];
                        $var->type = "string";
                        
                    }
                    else {
                        throw new InterpretRuntimeException("Invalid string operation", ReturnCode::STRING_OPERATION_ERROR);
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            case 'SETCHAR':
                $var = $this->get_symbol($instruction->arguments[0]);
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);
                            
                if ($var->type === 'string' && $symbol1->type === 'int' && $symbol2->type === 'string') {
                    if ($symbol1->value >= 0 && $symbol1->value < strlen($var->value)) {
                        $var->value[$symbol1->value] = $symbol2->value[0];
                    } 
                    else {
                        throw new InterpretRuntimeException("Index out of bounds", ReturnCode::STRING_OPERATION_ERROR);
                    }
                } 
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $this->inst_cnt++;
                break;
            
            case 'JUMPIFEQ':                                        // <label> <symb> <symb>
                $l_name = $instruction->arguments[0]->value;
                if (!array_key_exists($l_name, $this->labels)) {
                    throw new InterpretRuntimeException("Call to undefined label -" . $l_name, ReturnCode::SEMANTIC_ERROR);
                }
                
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);

                if ($symbol1->type !== $symbol2->type && $symbol1->type !== "nil" && $symbol2->type !== "nil") {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                if ($symbol1->type == $symbol2->type && $symbol1->value == $symbol2->value) {
                    return $this->labels[$l_name];
                }
                
                $this->inst_cnt++;
                break;
            case 'JUMPIFNEQ':
                $l_name = $instruction->arguments[0]->value;
                if (!array_key_exists($l_name, $this->labels)) {
                    throw new InterpretRuntimeException("Call to undefined label -" . $l_name, ReturnCode::SEMANTIC_ERROR);
                }
                
                $symbol1 = $this->get_symbol($instruction->arguments[1]);
                $symbol2 = $this->get_symbol($instruction->arguments[2]);

                if ($symbol1->type !== $symbol2->type && $symbol1->type !== "nil" && $symbol2->type !== "nil") {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                if ($symbol1->type != $symbol2->type || $symbol1->value != $symbol2->value) {
                    return $this->labels[$l_name];
                }
                
                $this->inst_cnt++;
                break;
            
            // STACK rozsirenie
            case 'ADDS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }
            
                // Pop the top two symbols from the stack
                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);
                // Check types of symbols
                if ($symb1->type != 'int' || $symb2->type != 'int') {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
            
                $result = $symb1->value + $symb2->value;
            
                // Store the result back onto the stack at the same position
                $this->stack[] = new Symbol($result, 'int');
            
                break;
            case 'SUBS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);
                // Check types of symbols
                if ($symb1->type != 'int' || $symb2->type != 'int') {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $result = $symb1->value - $symb2->value;
            
                // Store the result back onto the stack at the same position
                $this->stack[] = new Symbol($result, 'int');
                
                $this->inst_cnt++;
                break;    
            
            case 'MULS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);
                // Check types of symbols
                if ($symb1->type != 'int' || $symb2->type != 'int') {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                
                $result = $symb1->value * $symb2->value;
            
                // Store the result back onto the stack at the same position
                $this->stack[] = new Symbol($result, 'int');
                
                $this->inst_cnt++;
                break;
            
            case 'IDIVS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);
                // Check types of symbols
                if ($symb1->type != 'int' || $symb2->type != 'int') {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                if ($symb2->value === 0) {
                    throw new InterpretRuntimeException("Division by 0", ReturnCode::OPERAND_VALUE_ERROR);
                }
                
                $result = $symb1->value / $symb2->value;
            
                // Store the result back onto the stack at the same position
                $this->stack[] = new Symbol($result, 'int');
                
                $this->inst_cnt++;
                break;
            
            case 'LTS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);      

                if ($symb1->type == $symb2->type && ($symb1->type != "nil" && $symb2->type != "nil")) {
                    $result = $symb1->value < $symb2->value ? true : false;
                    $this->stack[] = new Symbol($result, "bool");
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'GTS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);      

                if ($symb1->type == $symb2->type && ($symb1->type != "nil" && $symb2->type != "nil")) {
                    $result = $symb1->value > $symb2->value ? true : false;
                    $this->stack[] = new Symbol($result, "bool");
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'EQS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);      
                
                if (!$symb1->type || !$symb2->type) {
                    throw new InterpretRuntimeException("Accessing not initialized variable", ReturnCode::VALUE_ERROR);
                }
                if ($symb1->type != $symb2->type && $symb1->type != "nil" && $symb2->type != "nil") {
                    throw new InterpretRuntimeException("Incompatible operand types in EQ", ReturnCode::OPERAND_TYPE_ERROR);
                }

                if ($symb1->value === $symb2->value) {
                    $this->stack[] = new Symbol(true, "bool");
                }
                else {
                    $this->stack[] = new Symbol(false, "bool");
                }

                $this->inst_cnt++;
                break;
            case 'ANDS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);

                if ($symb1->type == 'bool' && $symb2->type == 'bool') {
                    if ($symb1->value == "true" && $symb2->value == "true") {
                        $this->stack[] = new Symbol(true, "bool");
                    }
                    else {
                        $this->stack[] = new Symbol(false, "bool");
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'ORS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);

                if ($symb1->type == 'bool' && $symb2->type == 'bool') {
                    if ($symb1->value == false && $symb2->value == false) {
                        $this->stack[] = new Symbol(false, "bool");
                        
                    }
                    else {
                        $this->stack[] = new Symbol(true, "bool");
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'NOTS':
                if (count($this->stack) < 1) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb = array_pop($this->stack);

                if ($symb->type == "bool") {
                    if ($symb->value == true) {
                        $this->stack[] = new Symbol(false, "bool");
                        
                    }
                    elseif ($symb->value == false) {
                        $this->stack[] = new Symbol(true, "bool");
                    }
                }
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'INT2CHARS':
                if (count($this->stack) < 1) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb = array_pop($this->stack);

                if ($symb->type !== 'int') {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }
                $char = mb_chr($symb->value, "UTF-8");
                if (!$char) {
                    throw new InterpretRuntimeException("Failed to convert integer to character", ReturnCode::STRING_OPERATION_ERROR);
                }

                $this->stack[] = new Symbol($char, "string");

                $this->inst_cnt++;
                break;
            case 'STRI2INTS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);

                if ($symb1->type === "string" && $symb2->type === "int" && $symb2->value >= 0) {
                    if ($symb2->value < strlen($symb1->value)) {
                        $result = mb_ord($symb1->value[$symb2->value], "UTF-8");
                        $this->stack[] = new Symbol($result, "int");
                    } 
                    else {
                        throw new InterpretRuntimeException("Invalid string operation", ReturnCode::STRING_OPERATION_ERROR);
                    }
                } 
                else {
                    throw new InterpretRuntimeException("Invalid operand types", ReturnCode::OPERAND_TYPE_ERROR);
                }

                $this->inst_cnt++;
                break;
            case 'JUMPIFEQS':
                if (count($this->stack) < 3) {
                    throw new InterpretRuntimeException("Not enough operands on the stack for JUMPIFEQS", ReturnCode::OPERAND_VALUE_ERROR);
                }
                
                $symbol2 = array_pop($this->stack);
                $symbol1 = array_pop($this->stack);
            
                $this->inst_cnt++;
                break;
            case 'JUMPIFNEQS':
                if (count($this->stack) < 2) {
                    throw new InterpretRuntimeException("Not enough operands on the stack", ReturnCode::OPERAND_VALUE_ERROR);
                }

                $symb2 = array_pop($this->stack);
                $symb1 = array_pop($this->stack);

                $this->inst_cnt++;
                break;

            default:
                throw new \Exception("Unknown opcode in switch: " . $instruction->get_opcode());
        }
        return "no_jump";
    }

    private function get_frame_from_name($var_name) {
        $prefix = substr($var_name, 0, 2);
    
        switch ($prefix) {
            case 'GF':
                return $this->gf;
            case 'LF':
                if (count($this->lf) == 0) {
                    return null;
                }
                return end($this->lf);
            case 'TF':
                if (!isset($this->tf)) {
                    return null;
                }
                return $this->tf;
            default:
                // handled while parsing argument
        }
    }

    private function get_symbol($arg): Symbol {
        if ($arg->type == "var") {
            $frame = $this->get_frame_from_name($arg->value);
            if (!$frame) {
                throw new InterpretRuntimeException("Frame not initialized/doesn't exist", ReturnCode::FRAME_ACCESS_ERROR);
            }
            return $frame->get_variable(substr($arg->value, 3));
        }
        return new Symbol($arg->value, $arg->type);
    }
}

?>
